import { handleLogin } from "@/lib/auth-handlers";

export const POST = handleLogin;
