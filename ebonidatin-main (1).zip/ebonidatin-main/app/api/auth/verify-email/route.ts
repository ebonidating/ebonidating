import { handleVerifyEmail } from "@/lib/auth-handlers";

export const POST = handleVerifyEmail;
