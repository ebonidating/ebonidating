import { handleSignup } from "@/lib/auth-handlers";

export const POST = handleSignup;
